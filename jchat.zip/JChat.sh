cp un_tk ~
cp txt_msg ~
cp secret ~
cp tokens ~
cp wsgi.py /var/www/$(whoami)_pythonanywhere_com_wsgi.py
