import random
def app(path):
    global txt,tokens,secret,owner,un_tk
    out=""
    try:
        #send code 200 response
        path=path[1:]
        if "g"==path.split(",")[0]:
            out+=(txt)
        if "p"==path.split(",")[0]:
            txt+=tokens[path.split(",")[1]]+": "+path.split(",")[2].replace("%20"," ")+"\n"
            txt2=open('txt-msg','w')
            txt2.write(txt)
            txt2.close()
            print(txt)
        elif "c"==path.split(",")[0]:
            secret[path.split(",")[1]]=path.split(",")[2]
            token=random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")
            tokens[token]=path.split(",")[1]
            out+=(token)
            i=open('tokens','w')
            i.write(str(tokens))
            i.close()
            sec_file=open("secret","w")
            sec_file.write(str(secret))
            sec_file.close()
            un_tk[path.split(",")[1]]=token
            un=open("un_tk","w")
            un.write(str(un_tk))
            un.close()
        elif "s"==path.split(",")[0]:
            sec_file=open("secret","w")
            sec_file.write(str(secret))
            sec_file.close()
        if "l"==path.split(",")[0]:
            if secret[path.split(",")[1]]==path.split(",")[2]:
                out+=(un_tk[path.split(",")[1]])
        elif "o"==path.split(",")[0]:
            if tokens[path.split(",")[1]]==owner:
                if "b"==path.split(",")[2]:
                    pswd=random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")+random.choice("abcdefghijklmnopqrstuvwxyz1234567890")
                    print("Banning: "+path.split(",")[3]+"'s password is now: "+pswd)
                    secret[path.split(",")[3]]=pswd
        return out
        txt2=open('txt-msg','w')
        txt2.write(txt)
        txt2.close()
        tokens2=open('tokens','w')
        tokens2.write(str(tokens))
        tokens2.close()
    except IOError:
        self.send_error(404, 'file not found')
def application(environ, start_response):
    global txt,tokens,secret,owner,un_tk
    print('JChat is starting...')
    txt=open('txt-msg','r').read()
    print(txt)
    owner="ih8"
    tokens=eval(open('tokens','r').read())
    un_tk=eval(open('un_tk','r').read())
    print(str(tokens))
    secret={}
    try:
        sec_file=open("secret","r").read()
    except:
        sec_file="{}"
    secret=eval(sec_file)
    content=app(environ.get('PATH_INFO'))
    status="200 OK"
    response_headers = [('Content-Type', 'text/html'), ('Content-Length', str(len(content)))]
    start_response(status, response_headers)
    yield content.encode('utf8')
